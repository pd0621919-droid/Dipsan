# Beast Anime Studio — Cloud Queue V2

Mobile-first lightweight web dashboard plus a FastAPI reference backend for Google Cloud Storage temporary episode storage.

- Open `frontend/index.html` locally for the UI demo.
- Backend reference: `backend/main.py`
- Configure secrets server-side using `backend/.env.example`.
- Read `backend/WORKFLOW.md` before enabling cloud deletion.

This does not run AI video generation or YouTube publishing by itself. It provides the storage API and safe workflow outline to connect to a cloud rendering/upload worker. Cloud services may cost money.
