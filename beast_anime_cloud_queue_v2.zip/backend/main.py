"""
Cloud queue reference backend.
Run: pip install -r requirements.txt && uvicorn main:app --reload
Configure GCS_BUCKET and Application Default Credentials before using.
Never expose service-account credentials to the browser.
"""
import os, uuid
from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from google.cloud import storage

app=FastAPI(title="Beast Anime Cloud Queue")
BUCKET=os.environ.get("GCS_BUCKET","")
PREFIX=os.environ.get("TEMP_PREFIX","episodes/temporary").strip("/")
def bucket():
    if not BUCKET: raise HTTPException(503,"Set GCS_BUCKET on the server")
    return storage.Client().bucket(BUCKET)

class Episode(BaseModel):
    day:int
    local_path:str
    title:str

@app.get("/health")
def health(): return {"ok":True,"service":"cloud-queue"}

@app.post("/episodes")
def store_episode(ep:Episode):
    # Upload a rendered episode to private temporary GCS storage.
    if not os.path.isfile(ep.local_path): raise HTTPException(404,"Rendered file not found")
    blob=bucket().blob(f"{PREFIX}/day-{ep.day}-{uuid.uuid4().hex}.mp4")
    blob.upload_from_filename(ep.local_path,content_type="video/mp4")
    blob.metadata={"day":str(ep.day),"title":ep.title,"uploaded_at":datetime.now(timezone.utc).isoformat()}
    blob.patch()
    return {"name":blob.name,"size":blob.size,"status":"stored"}

@app.get("/episodes")
def list_episodes():
    return [{"name":b.name,"size":b.size,"updated":b.updated.isoformat() if b.updated else None} for b in bucket().list_blobs(prefix=PREFIX+"/")]

@app.delete("/episodes")
def delete_temporary_episode(name:str):
    # Only delete objects within the configured temporary prefix.
    if not name.startswith(PREFIX+"/"): raise HTTPException(400,"Only temporary episode objects may be deleted")
    bucket().blob(name).delete()
    return {"deleted":name}

@app.post("/workflow/uploaded")
def upload_confirmed(day:int, object_name:str):
    """
    Call ONLY after YouTube upload returns a video ID and verification passes.
    Production implementation should enqueue generation for day+1, then delete
    the day object's temporary GCS copy only after the next render is safely stored.
    """
    if not object_name.startswith(PREFIX+"/day-"+str(day)+"-"):
        raise HTTPException(400,"Object does not match day/prefix")
    # Deliberately do not delete here: require an explicit successful YouTube
    # confirmation and next-day durable-storage check in the worker.
    return {"day":day,"next_day_to_prepare":day+1,"cleanup":"pending_worker_confirmation"}
