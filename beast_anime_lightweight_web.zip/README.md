# Beast Anime Studio — Lightweight Web V1

This is a mobile-friendly static web app. It does NOT run heavy AI/video processing on the phone.

Included:
- Original anime universe editor
- Childhood -> growing up -> teen -> adult chapter progression
- Chapter generator (local demo)
- Hindi/English/Hinglish settings
- 4 Shorts + 2 long-video planner
- YouTube connection workflow placeholder
- SEO pack generator
- PWA/offline cache
- LocalStorage project saving

IMPORTANT:
A real AI video generator, Hindi TTS, YouTube OAuth upload, analytics, and cloud rendering need a server/cloud backend. This front end is intentionally lightweight for low-end phones.

Free hosting:
- GitHub Pages
- Cloudflare Pages
- Netlify
Upload the files in this folder. No Docker is needed for the front end.

For real automation, connect a backend later. Never put Google OAuth client secrets or API secrets inside these front-end files.
