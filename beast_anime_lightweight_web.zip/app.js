const KEY="beastAnimeProjectV1";
const stages=[
 ["Childhood","fun, friendship, games, funny beast adventures, a baby dragon"],
 ["Childhood","forest race, festival, treasure hunt, secret ancient symbol"],
 ["Growing Up","first training mission, rival friendship, lost beast"],
 ["Growing Up","mysterious ruins, parent secret, first dangerous chase"],
 ["Teen Era","shadow villain, dragon trail, daring mountain chase"],
 ["Teen Era","ancient city escape, beast rescue, major mystery"],
 ["Adult Era","dragon war begins, floating kingdom chase, ancient guardians"],
 ["Adult Era","final kingdom, ancient beast awakens, final battle"]
];
let state=JSON.parse(localStorage.getItem(KEY)||'{"chapters":[],"youtube":false,"long":2,"shorts":4}');
const $=id=>document.getElementById(id);
function save(){localStorage.setItem(KEY,JSON.stringify(state));render();}
function toast(s){$("toast").textContent=s;$("toast").style.display="block";setTimeout(()=>$("toast").style.display="none",1800)}
function render(){
 $("chapterCount").textContent=state.chapters.length;
 $("videoCount").textContent=state.chapters.length;
 $("shortCount").textContent=state.chapters.length*2;
 $("latest").innerHTML=state.chapters.length?`<b>Chapter ${state.chapters.at(-1).number}: ${state.chapters.at(-1).title}</b><p>${state.chapters.at(-1).stage} — ${state.chapters.at(-1).idea}</p>`:"No chapter yet. Create one above.";
 $("ytStatus").textContent=state.youtube?"Connected (demo mode — OAuth backend required)":"Not connected";
 $("longPerDay").value=state.long;$("shortsPerDay").value=state.shorts;
 renderSlots();
}
function createChapter(){
 const n=state.chapters.length+1, s=stages[Math.min(n-1,stages.length-1)];
 const titles=["The First Beast Race","The Baby Dragon","Secret of the Ancient Mark","The Chase Through Mistwood","The Shadow Rider","Escape From the Ancient City","War Above the Clouds","The Ancient Beast Awakens"];
 const idea=s[1];
 state.chapters.push({number:n,title:titles[Math.min(n-1,titles.length-1)],stage:s[0],idea});
 save(); toast("Chapter created");
}
function renderSlots(){
 let html="";
 for(let i=0;i<state.long;i++)html+=`<div class="notice">🎬 Long video ${i+1}: suggested evening slot</div>`;
 for(let i=0;i<state.shorts;i++)html+=`<div class="notice">📱 Short ${i+1}: suggested separate daily slot</div>`;
 $("slots").innerHTML=html||"<p>No uploads planned.</p>";
}
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));$(b.dataset.page).classList.add("active")});
$("createBtn").onclick=createChapter;
$("saveStory").onclick=()=>{state.story={title:$("title").value,hero:$("hero").value,bible:$("bible").value};save();toast("Universe saved")};
$("saveSchedule").onclick=()=>{state.long=+$("longPerDay").value||0;state.shorts=+$("shortsPerDay").value||0;save();toast("Schedule saved")};
$("connectBtn").onclick=()=>{state.youtube=true;save();toast("Demo connection enabled — add OAuth on server")};
$("seoBtn").onclick=()=>{let t=$("seoTopic").value; $("seoResult").textContent=`TITLE: ${t} | Original Anime Story\\nDESCRIPTION: An original fantasy anime adventure featuring beasts, ancient secrets and daring chases.\\nHASHTAGS: #Anime #Fantasy #Dragon #Beast #HindiAnime #OriginalAnime`;};
$("themeBtn").onclick=()=>document.body.classList.toggle("light");
$("clearBtn").onclick=()=>{if(confirm("Clear this phone's local project?")){localStorage.removeItem(KEY);state={chapters:[],youtube:false,long:2,shorts:4};render();toast("Project cleared")}};
if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js");
render();